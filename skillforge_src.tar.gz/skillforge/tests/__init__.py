"""SkillForge test suite."""
