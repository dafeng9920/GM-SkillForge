---
name: LOBSTER_INTELLIGENCE_HARVESTER
description: SEO Matrix 专用情报收割协议。用于大规模探测 AI 搜索引用动态、挖掘高意图 Leads 并填充 pSEO 行业数据库。
---

# 🦞 LOBSTER_INTELLIGENCE_HARVESTER (SEO Matrix 特勤协议)

此技能用于指导 AI 特工（Little Lobster）在 SEO Matrix 项目中执行“情报工厂”和“舆情捕鱼”任务。

## 🎯 核心目标
1.  **大规模工业侦察**：为 pSEO 引擎提供行业数据。
2.  **高意图 Leads 挖掘**：通过社交媒体抓取迫切需要 AIO 优化的潜在客户。
3.  **竞品引用扫描**：监控 Perplexity 和 Google AIO 的信源变动。

---

## 🛠 任务指令 (Instruction Set)

### 任务 A：行业数据自动化填充 (The pSEO Harvester)
**执行逻辑**：
1.  研究指定的垂直行业（如：Cybersecurity, EdTech, Managed Services）。
2.  识别该行业的前 50 个核心品牌及其主要业务关键词。
3.  估算其 **AEV (每年隐形成本价值)** = `月均搜索量 * 0.8 (由于 AI 导致的流量损失) * $4 (平均 CPC) * 12`。
4.  **产出**：将结果按照 `d:\GM-SkillForge\data\pSEO_Industries.json` 的格式追加到文件中。

### 任务 B：社交媒体“病理”钓鱼 (Social Lead Scraper)
**执行逻辑**：
1.  监控 Reddit (`r/SEO`, `r/SaaS`, `r/Marketing`) 和 X (Twitter) 的实时动态。
2.  搜寻关键词：`Perplexity citations`, `AIO traffic drop`, `ChatGPT Search visibility`, `Gemini Search sources`.
3.  对抱怨流量下滑或寻求 AI 搜索优化的用户进行实体识别。
4.  **产出**：将发现的域名和联系方式追加到 `d:\GM-SkillForge\skillforge\captured_leads.json`，标记来源为 `Social_Scout`。

### 任务 C：实时引用监控 (Citation Monitor)
**执行逻辑**：
1.  使用 `AI_SEARCH_SCANNER` 扫描指定的 5 个竞品域名。
2.  对比其在 Perplexity 和 ChatGPT 结果中的排位。
3.  记录其“神经路径 (Neural Thought Process)”中的关键弱点。
4.  **产出**：在 `d:\GM-SkillForge\docs\Pathogen_Intel.md` 中生成对比报告，供 Commander 用于市场营销素材（对比图）。

---

- **治理约束 (Governance)**: 严格执行【代码只读】原则。严禁修改或尝试写入任何 `.py` (Python) 或 `.html` (Template) 文件。
- **合法写入区域**: 仅限于 `data/` 内容追加、`pseo/` 页面生成、`docs/` 情报报告。
- **违规处置**: 任何越权修改核心代码的行为将触发即时会话止损。

---
*Created by Antigravity for Commander.* 🛰️🔥🦞
